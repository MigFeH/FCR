#include <iostream>
#include <iomanip>

using namespace std;

void checkIntSizes(void)
{
	cout << "Size of short integers (signed and unsigned): " << sizeof(short int) * 8 << " bits" << endl;
	cout << "Size of integers (signed and unsigned): " << sizeof(int) * 8 << " bits" << endl;
	cout << "Size of long long integers (signed and unsigned): " << sizeof(long long int) * 8 << " bits" << endl;
}

int main()
{
	signed float var1 = (float)-10023;
	unsigned int var2 = 12056534;
	signed int var3 = -1000;

	checkIntSizes();

	char string1[] = "$~)645slsod";
	char string2[] = "dwjnnw8$~%";
	
	// var2 >= var3 ?
	if (var2 >= var3)
		cout << "var2 >= var3" << endl;

	system("pause");

	return 0;
}
